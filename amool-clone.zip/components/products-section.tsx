import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function ProductsSection() {
  const products = [
    {
      title: "Dr. Verghese Kurien",
      subtitle: "26 November 1921 - 9 September 2012",
      image: "/dr-verghese-kurien-portrait-with-dairy-background.jpg",
      bgColor: "bg-gradient-to-br from-blue-600 to-blue-800",
    },
    {
      title: "Locate Amul Products",
      subtitle: "near your location",
      image: "/mobile-app-interface-for-finding-amul-products.jpg",
      bgColor: "bg-gradient-to-br from-blue-500 to-cyan-600",
      hasButton: true,
    },
    {
      title: "Amul Plant Visit Program",
      subtitle: "Experience our manufacturing process",
      image: "/amul-dairy-plant-facility-with-visitors.jpg",
      bgColor: "bg-gradient-to-br from-green-600 to-teal-700",
    },
  ]

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          {products.map((product, index) => (
            <Card
              key={index}
              className={`overflow-hidden shadow-lg hover:shadow-xl transition-shadow ${product.bgColor} text-white`}
            >
              <CardContent className="p-0">
                <div className="relative">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{product.title}</h3>
                  <p className="text-white/90 mb-4">{product.subtitle}</p>
                  {product.hasButton && (
                    <div className="flex items-center gap-2">
                      <Button variant="secondary" size="sm">
                        Download it now from
                      </Button>
                      <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
                        <span className="text-xs font-bold text-black">GP</span>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
