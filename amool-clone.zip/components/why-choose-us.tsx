import { Shield, Clock, MapPin, Package } from "lucide-react"

export function WhyChooseUs() {
  const features = [
    {
      icon: Shield,
      title: "Global supply Chain Solutions",
      description: "Efficiently unleash cross-media information without cross-media value.",
    },
    {
      icon: Clock,
      title: "24 Hours - Technical Support",
      description: "Specialises in international freight forwarding of merchandise and associated logistic services",
    },
    {
      icon: MapPin,
      title: "Mobile Shipment Tracking",
      description: "We Offers intellgent concepts for road and tail and well as complex special transport services",
    },
    {
      icon: Package,
      title: "Careful Handling of Valuable Goods",
      description: "Cargo Amool are transported at some stage of their journey along the world's roads",
    },
  ]

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-8">Why Choosing us?</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {features.map((feature, index) => (
            <div key={index} className="flex gap-4 group">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-secondary transition-colors">
                <feature.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2 text-balance">{feature.title}</h3>
                <p className="text-muted-foreground text-pretty">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
