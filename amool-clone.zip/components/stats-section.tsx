export function StatsSection() {
  const stats = [
    { number: "9800", label: "Satisfied Packages", color: "bg-secondary" },
    { number: "230", label: "Happy Customers", color: "bg-secondary" },
    { number: "1200", label: "Shipments", color: "bg-secondary" },
    { number: "5200", label: "Years of Service", color: "bg-secondary" },
  ]

  return (
    <section className="py-16 bg-primary text-primary-foreground relative overflow-hidden">
      {/* Background pattern */}
      <div
        className="absolute inset-0 opacity-10 bg-cover bg-center"
        style={{
          backgroundImage: `url('/logistics-network-pattern-background.jpg')`,
        }}
      />

      <div className="container mx-auto px-4 relative">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            Cargo <span className="text-secondary">Amool</span> is a Global Supplier of
            <br />
            Transport and logistics Solutions.
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-5xl md:text-6xl font-bold mb-2 text-secondary">{stat.number}</div>
              <div
                className={`inline-block px-4 py-2 ${stat.color} text-primary-foreground text-sm font-medium rounded`}
              >
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
