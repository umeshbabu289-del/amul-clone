"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Play } from "lucide-react"

export function VideoSection() {
  return (
    <section className="py-16 bg-gradient-to-r from-blue-50 to-pink-50">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Left video card */}
          <Card className="overflow-hidden shadow-xl hover:shadow-2xl transition-shadow">
            <CardContent className="p-0 relative">
              <img src="/amul-pehla-pyaar-video-thumbnail-with-couple-and-d.jpg" alt="Pehla Pyaar Amul Pyaar" className="w-full h-64 object-cover" />
              <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center hover:scale-110 transition-transform cursor-pointer">
                  <Play className="h-8 w-8 text-primary-foreground ml-1" />
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                <h3 className="text-white font-semibold text-lg">Pehla Pyaar Amul Pyaar</h3>
              </div>
            </CardContent>
          </Card>

          {/* Right content */}
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-gray-800 to-gray-900 text-white p-8 rounded-xl">
              <h2 className="text-2xl font-bold mb-4">A long and distinguished innings</h2>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                  <div className="text-2xl">🏏</div>
                </div>
                <div>
                  <p className="text-lg font-semibold">Dickie Bird</p>
                  <p className="text-sm text-gray-300">1933-2025</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-8 h-6 bg-blue-600 text-white flex items-center justify-center text-xs font-bold">f</div>
              <span>Like 1.6M</span>
              <span className="ml-auto">View more topicals...</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
