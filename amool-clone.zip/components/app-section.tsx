import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Smartphone, MapPin } from "lucide-react"

export function AppSection() {
  return (
    <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-700 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Find Amul Products Near You</h2>
          <p className="text-xl text-white/90">Download our app to locate the nearest Amul store</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <MapPin className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-xl font-semibold">Store Locator</h3>
                <p className="text-white/80">Find the nearest Amul outlet in your area</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <Smartphone className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-xl font-semibold">Product Catalog</h3>
                <p className="text-white/80">Browse our complete range of dairy products</p>
              </div>
            </div>

            <div className="flex gap-4">
              <Button variant="secondary" size="lg" className="flex items-center gap-2">
                <div className="w-6 h-6 bg-black rounded flex items-center justify-center">
                  <span className="text-xs font-bold text-white">GP</span>
                </div>
                Google Play
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-primary bg-transparent"
              >
                App Store
              </Button>
            </div>
          </div>

          <div className="flex justify-center">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-8">
                <img src="/mobile-phone-showing-amul-app-interface-with-store.jpg" alt="Amul Mobile App" className="w-full max-w-xs mx-auto" />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
