"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

export function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0)

  const slides = [
    {
      title: "GST Benefits",
      subtitle: "Check which of your favourites cost less. Thanks to GST 2.0!",
      image: "/colorful-amul-girl-mascot-with-gst-message-and-dai.jpg",
      bgColor: "from-blue-100 to-pink-100",
    },
    {
      title: "Pehla Pyaar Amul Pyaar",
      subtitle: "Experience the taste of pure love with Amul",
      image: "/placeholder-0tn8z.png",
      bgColor: "from-pink-100 to-yellow-100",
    },
    {
      title: "Fresh Dairy Products",
      subtitle: "From farm to your table - pure and fresh",
      image: "/placeholder-r9esq.png",
      bgColor: "from-green-100 to-blue-100",
    },
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [slides.length])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)
  }

  return (
    <section className="relative h-[500px] overflow-hidden">
      <div className={`absolute inset-0 bg-gradient-to-r ${slides[currentSlide].bgColor} transition-all duration-1000`}>
        <div className="container mx-auto px-4 h-full flex items-center">
          <div className="grid md:grid-cols-2 gap-8 items-center w-full">
            {/* Left content */}
            <div className="space-y-6">
              <div className="animate-bounce-gentle">
                <div className="w-20 h-20 bg-gradient-to-br from-pink-200 to-pink-300 rounded-full flex items-center justify-center mb-4">
                  <div className="text-3xl">👧</div>
                </div>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold gradient-text text-balance">
                {slides[currentSlide].title}
              </h1>
              <p className="text-lg text-foreground/80 text-pretty">{slides[currentSlide].subtitle}</p>
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full px-8 py-6 text-lg font-semibold shadow-lg hover:shadow-xl transition-all"
              >
                CLICK HERE
              </Button>
            </div>

            {/* Right image */}
            <div className="flex justify-center">
              <img
                src={slides[currentSlide].image || "/placeholder.svg"}
                alt={slides[currentSlide].title}
                className="max-w-full h-auto animate-float"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Navigation arrows */}
      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/80 hover:bg-white rounded-full flex items-center justify-center transition-all shadow-lg hover:shadow-xl"
      >
        <ChevronLeft className="h-6 w-6 text-primary" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/80 hover:bg-white rounded-full flex items-center justify-center transition-all shadow-lg hover:shadow-xl"
      >
        <ChevronRight className="h-6 w-6 text-primary" />
      </button>

      {/* Slide indicators */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all ${index === currentSlide ? "bg-primary" : "bg-white/50"}`}
          />
        ))}
      </div>
    </section>
  )
}
