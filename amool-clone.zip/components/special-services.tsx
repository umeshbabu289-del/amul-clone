import { Package, Warehouse, Truck, Globe, MapPin } from "lucide-react"

export function SpecialServices() {
  const services = [
    {
      icon: Package,
      title: "Packaging And Storage",
      description: "Package and store your things effectively and securely to make sure them in storage.",
    },
    {
      icon: Warehouse,
      title: "Warehousing",
      description: "Package and store your things effectively and securely to make sure them in storage.",
    },
    {
      icon: Truck,
      title: "Cargo",
      description: "Delivery of any freight from a place to another place quickly to save your cost and your time.",
    },
    {
      icon: Globe,
      title: "Worldwide Transport",
      description:
        "Specialises in international freight forwarding of merchandise and associated general logistic services.",
    },
    {
      icon: MapPin,
      title: "Ground Transport",
      description: "Ground transportation options for all visitors, no matter your needs, schedule or destination.",
    },
  ]

  return (
    <section className="py-16 bg-primary text-primary-foreground">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">Our Special SERVICES</h2>
          <p className="text-primary-foreground/90 max-w-3xl mx-auto text-pretty">
            Our warehousing services are known nationwide to be one of the most reliable, safe and affordable, because
            we take pride in delivering the best of warehousing services, at the most reasonable prices.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="text-center group">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary-foreground/20 rounded-full flex items-center justify-center group-hover:bg-secondary transition-colors">
                <service.icon className="h-8 w-8 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-3 text-balance">{service.title}</h3>
              <p className="text-primary-foreground/80 text-sm text-pretty">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
