export function WelcomeSection() {
  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-8">
            WELCOME TO CARGO <span className="text-secondary">AMOOL</span>
          </h2>

          {/* Video grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {[1, 2, 3, 4, 5].map((index) => (
              <div
                key={index}
                className="relative aspect-video bg-muted rounded-lg overflow-hidden group cursor-pointer"
              >
                <div
                  className="w-full h-full bg-cover bg-center"
                  style={{
                    backgroundImage: `url('/logistics-warehouse-operations-video-thumbnail---i.jpg')`,
                  }}
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                  <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center">
                    <div className="w-0 h-0 border-l-[12px] border-l-primary-foreground border-y-[8px] border-y-transparent ml-1" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <p className="text-muted-foreground mt-8 max-w-3xl mx-auto text-pretty">
            Amool is more than logistics. We can also optimize your packaging, manage your materials sourcing, and so
            much more.
          </p>
        </div>
      </div>
    </section>
  )
}
