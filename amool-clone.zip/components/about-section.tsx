export function AboutSection() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold mb-4">
              ABOUT CARGO <span className="text-secondary">AMOOL</span>
            </h2>
          </div>

          <div className="prose prose-lg mx-auto text-center">
            <p className="text-muted-foreground text-pretty">
              Cargo AMOOL Logistics Services is a global supplier of transport and logistics solutions. We have offices
              in more than 20 countries and an international network of partners and agents.
            </p>
            <p className="text-muted-foreground mt-4 text-pretty">
              Established in 2003 and rebranded in 2010, we provide comprehensive cargo and logistics services with
              branches in China (Yiwu, Guangzhou), Iraq (Erbil, Duhok, Mosul, Baghdad), and Turkey (Istanbul,
              Gaziantep).
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
