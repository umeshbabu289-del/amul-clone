import { Card, CardContent } from "@/components/ui/card"

export function NewsSection() {
  return (
    <section className="py-16 bg-gradient-to-r from-pink-50 to-yellow-50">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          {/* News column */}
          <div className="md:col-span-1">
            <h2 className="text-2xl font-bold text-primary mb-6">What's New? Archive...</h2>
            <div className="space-y-4">
              <Card className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <h3 className="font-semibold text-primary hover:underline cursor-pointer">Amul Parlours</h3>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Main content area */}
          <div className="md:col-span-3">
            <div className="bg-white rounded-xl p-8 shadow-lg">
              <div className="text-center mb-8">
                <div className="inline-block animate-bounce-gentle">
                  <div className="w-24 h-24 bg-gradient-to-br from-pink-200 to-pink-300 rounded-full flex items-center justify-center mb-4">
                    <div className="text-4xl">👧</div>
                  </div>
                </div>
                <h2 className="text-3xl font-bold gradient-text mb-4">Welcome to Amul</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  India's largest dairy cooperative, bringing you the finest quality dairy products for over 75 years.
                  From farm to your table, we ensure freshness and purity in every product.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-primary">Our Products</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Fresh Milk & Dairy Products</li>
                    <li>• Amul Butter & Cheese</li>
                    <li>• Ice Creams & Frozen Desserts</li>
                    <li>• Chocolates & Confectionery</li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-primary">Quality Assurance</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• ISO Certified Manufacturing</li>
                    <li>• Farm-to-Fork Traceability</li>
                    <li>• State-of-the-art Processing</li>
                    <li>• Rigorous Quality Testing</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
