"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X, Search, Facebook, Twitter, Instagram, Linkedin, Youtube } from "lucide-react"
import { Input } from "@/components/ui/input"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-background">
      {/* Top bar with social icons */}
      <div className="bg-gradient-to-r from-primary via-secondary to-accent text-white">
        <div className="container mx-auto px-4 py-2">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline">Follow us:</span>
              <div className="flex gap-2">
                <Facebook className="h-4 w-4 hover:scale-110 transition-transform cursor-pointer" />
                <Twitter className="h-4 w-4 hover:scale-110 transition-transform cursor-pointer" />
                <Instagram className="h-4 w-4 hover:scale-110 transition-transform cursor-pointer" />
                <Linkedin className="h-4 w-4 hover:scale-110 transition-transform cursor-pointer" />
                <Youtube className="h-4 w-4 hover:scale-110 transition-transform cursor-pointer" />
              </div>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <a href="#" className="hover:underline">
                Home
              </a>
              <a href="#" className="hover:underline">
                Contact Us
              </a>
              <a href="#" className="hover:underline">
                Sitemap
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main header with logo and mascot */}
      <div className="bg-gradient-to-r from-blue-50 to-yellow-50 relative overflow-hidden">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="text-4xl font-bold gradient-text">Amul</div>
              <div className="animate-bounce-gentle">
                <div className="w-16 h-16 bg-gradient-to-br from-pink-200 to-pink-300 rounded-full flex items-center justify-center">
                  <div className="text-2xl">👧</div>
                </div>
              </div>
            </div>

            {/* Search bar */}
            <div className="hidden md:flex items-center gap-2 bg-white rounded-full px-4 py-2 shadow-md">
              <Input placeholder="Searching for?" className="border-0 bg-transparent focus-visible:ring-0 w-64" />
              <Search className="h-5 w-5 text-primary cursor-pointer" />
            </div>

            {/* Mobile menu button */}
            <Button variant="ghost" size="sm" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-white shadow-md">
        <div className="container mx-auto px-4">
          <nav className="hidden md:flex">
            <a
              href="#"
              className="px-6 py-4 bg-accent text-accent-foreground hover:bg-accent/80 transition-colors font-medium"
            >
              Brands
            </a>
            <a href="#" className="px-6 py-4 bg-pink-500 text-white hover:bg-pink-600 transition-colors font-medium">
              GCMMF
            </a>
            <a
              href="#"
              className="px-6 py-4 bg-warning text-warning-foreground hover:bg-warning/80 transition-colors font-medium"
            >
              Fun @ amul
            </a>
            <a
              href="#"
              className="px-6 py-4 bg-orange-500 text-white hover:bg-orange-600 transition-colors font-medium"
            >
              Dairy News
            </a>
            <a
              href="#"
              className="px-6 py-4 bg-purple-500 text-white hover:bg-purple-600 transition-colors font-medium"
            >
              Careers
            </a>
            <a
              href="#"
              className="px-6 py-4 bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors font-medium"
            >
              Amul for India
            </a>
            <a href="#" className="px-6 py-4 bg-red-500 text-white hover:bg-red-600 transition-colors font-medium">
              B2B
            </a>
            <a href="#" className="px-6 py-4 bg-green-500 text-white hover:bg-green-600 transition-colors font-medium">
              2025 Year of Cooperatives
            </a>
          </nav>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <nav className="md:hidden py-4">
              <div className="flex flex-col gap-2">
                <a href="#" className="px-4 py-3 bg-accent text-accent-foreground rounded-lg font-medium">
                  Brands
                </a>
                <a href="#" className="px-4 py-3 bg-pink-500 text-white rounded-lg font-medium">
                  GCMMF
                </a>
                <a href="#" className="px-4 py-3 bg-warning text-warning-foreground rounded-lg font-medium">
                  Fun @ amul
                </a>
                <a href="#" className="px-4 py-3 bg-orange-500 text-white rounded-lg font-medium">
                  Dairy News
                </a>
                <a href="#" className="px-4 py-3 bg-purple-500 text-white rounded-lg font-medium">
                  Careers
                </a>
                <a href="#" className="px-4 py-3 bg-secondary text-secondary-foreground rounded-lg font-medium">
                  Amul for India
                </a>
                <a href="#" className="px-4 py-3 bg-red-500 text-white rounded-lg font-medium">
                  B2B
                </a>
                <a href="#" className="px-4 py-3 bg-green-500 text-white rounded-lg font-medium">
                  2025 Year of Cooperatives
                </a>
              </div>
            </nav>
          )}
        </div>
      </div>
    </header>
  )
}
