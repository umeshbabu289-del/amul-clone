import { Plane, Ship, Truck } from "lucide-react"

export function ServicesSection() {
  const services = [
    {
      icon: Plane,
      title: "Air Freight Forwarding",
      description:
        "As a leader in global air freight forwarding, Amool excels in providing tailored transportation solutions for time-sensitive cargo.",
    },
    {
      icon: Ship,
      title: "Ocean Freight Forwarding",
      description:
        "Ocean Freight plays perhaps the most vital role in most transportation and supply chain solutions, connecting global markets efficiently.",
    },
    {
      icon: Truck,
      title: "Road Freight Forwarding",
      description:
        "Cargo are transported at some stage of their journey along the world's roads where we give you a reassuring presence.",
    },
  ]

  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="text-center group">
              <div className="w-20 h-20 mx-auto mb-6 bg-primary rounded-full flex items-center justify-center group-hover:bg-secondary transition-colors">
                <service.icon className="h-10 w-10 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-4 text-balance">{service.title}</h3>
              <p className="text-muted-foreground text-pretty">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
