import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { VideoSection } from "@/components/video-section"
import { ProductsSection } from "@/components/products-section"
import { NewsSection } from "@/components/news-section"
import { AppSection } from "@/components/app-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <Header />
      <HeroSection />
      <VideoSection />
      <ProductsSection />
      <NewsSection />
      <AppSection />
      <Footer />
    </main>
  )
}
